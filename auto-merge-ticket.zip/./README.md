## Auto Merge Ticket

Automatically detect and merge duplicate Freshservice tickets from the same requester

### App feature:

    1. Ticket fields - Choose one or more fields based on which tickets should be merged.
    2. Time restriction - Place a time constraint on duplicate detection. For eg. do not merge if the duplicate ticket was raised after 2 hours.
    4. The secondary ticket is closed
    6. A note is added to each of the secondary tickets with a link to the primary ticket.
    7. App will have 10 sec delay before start checking  for duplicates (to allow time for new tickets to be updated by workflows)

### Configuration details:

    1. API key
    2. Time restriction: Window duration window (in minutes)  within which tickets can be merged.
    3. Ticket fields : The app will support the following fields for determining duplicates
     - Requester (default)
     - Subject
     - Status
     - Group
     - Priority

### Project folder structure explained

    .
    ├── README.md                  This file.
    ├── config                     Installation parameter configs.
    │   ├── iparams.json           Installation parameter config in English language.
    │   └── iparam_test_data.json  Installation parameter data for local testing.
    └── manifest.json              Project manifest.
    └── server                     Business logic for remote request and event handlers.
        ├── lib
        │   └── handle-response.js
        ├── server.js              Server entry point.
        └── helpers.js             Helper functions used by the business logic.
        └── constants.js           Constants used by the business logic.
        └── test_data
            ├── onTicketCreate.json
            └── onTicketUpdate.json

### App developer

The app was developed and maintained by Exsead pvt ltd
(https://www.exsead.com.au)

Please contact us at info@exsead.com.au if you have any questions.
