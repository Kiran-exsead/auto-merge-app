function windowRangeChange(arg) {
  utils.set('windowDuration', { min: 1, max: 7200 });
  return arg > 7200 || arg < 0 ? 'Invalid time range. Should be between 1 - 7200 min' : '';
}
