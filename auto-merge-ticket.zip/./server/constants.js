const TICKET_FIELDS = {
  SUBJECT: 'subject',
  STATUS: 'status',
  GROUP: 'group',
  PRIORITY: 'priority',
};

exports = {
  TICKET_FIELDS: TICKET_FIELDS,
};
