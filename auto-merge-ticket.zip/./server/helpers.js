const { TICKET_FIELDS } = require('./constants');

function diffTime(a, b) {
  return new Date(a) - new Date(b);
}

function withInWindow(primary, secondary, windowDuration) {
  console.log(`
    secondary: ${secondary.created_at},
    primary: ${primary.created_at},
      window duration: ${windowDuration},
        diff: ${diffTime(secondary.created_at, primary.created_at)},
          duration in ms: ${windowDuration * 60 * 1000}
  `);
  console.log(
    'withInWindow :',
    diffTime(secondary.created_at, primary.created_at) < windowDuration * 60 * 1000 &&
      diffTime(secondary.created_at, primary.created_at) >= 0
  );
  return (
    diffTime(secondary.created_at, primary.created_at) < windowDuration * 60 * 1000 &&
    diffTime(secondary.created_at, primary.created_at) >= 0
  );
}

function compareTicketFields(primary, secondary, ticketFields) {
  if (ticketFields.length === 0) return true;

  const compareSuccessArray = ticketFields.map((field) => {
    console.log('field: ', field);
    if (field === TICKET_FIELDS.GROUP) {
      console.log('field values', primary.group_id, secondary.group_id, field);
      return !!primary.group_id && primary.group_id === secondary.group_id;
    } else {
      console.log('field values', primary[field], secondary[field]);
      return !!primary[field] && primary[field] === secondary[field];
    }
  });

  const compareFailed = compareSuccessArray.includes(false);
  console.log('compareSuccessArray: ', compareSuccessArray, ticketFields, compareFailed);
  return !compareFailed;
}

function generateSecondaryNote(primaryTicket) {
  return `This ticket is closed and merged into ticket <a href="${primaryTicket.id}">${primaryTicket.id}</a> by the Auto Merge Ticket App!`;
}

function generatePrimaryNote(secondaryTicket) {
  return `Merged from ticket <a href="${secondaryTicket.id}">${secondaryTicket.id}</a> by the Auto Merge Ticket App!<br /><br /><b>Subject: </b>${secondaryTicket.subject}<br /><br /><b>Description: </b>${secondaryTicket.description}`;
}

function validatedRequesterIds(reqIds, ticketReqId) {
  if (!reqIds.trim()) return true; // Return true if no requester ids provided by admin. We will consider all requesters
  const reqIdsArray = reqIds.split(',').map((item) => +item.trim());
  console.log(`validatedRequesterIds: ${reqIdsArray}  secondaryTicket: ${ticketReqId}`);
  return reqIdsArray.includes(ticketReqId);
}

exports = {
  compareTicketFields: compareTicketFields,
  withInWindow: withInWindow,
  generatePrimaryNote: generatePrimaryNote,
  generateSecondaryNote: generateSecondaryNote,
  validatedRequesterIds: validatedRequesterIds,
};
