const {
  withInWindow,
  compareTicketFields,
  generatePrimaryNote,
  generateSecondaryNote,
  validatedRequesterIds,
} = require('./helpers');

async function mergeWithPrimary({ primaryTicket, secondaryTicket }) {
  console.log(`Primary id :${primaryTicket.id}, Secondary id: ${secondaryTicket.id}`);
  try {
    // API : Update primary ticket with note
    await $request.invokeTemplate('updateTicketWithNoteAPI', {
      context: { ticketId: primaryTicket.id },
      body: JSON.stringify({
        private: true,
        body: generatePrimaryNote(secondaryTicket),
      }),
    });

    // API : Update secondary ticket with note
    await $request.invokeTemplate('updateTicketWithNoteAPI', {
      context: { ticketId: secondaryTicket.id },
      body: JSON.stringify({
        private: true,
        body: generateSecondaryNote(primaryTicket),
      }),
    });

    // API : Close secondary ticket by updating status
    await $request.invokeTemplate('closeSecondaryTicketAPI', {
      context: { ticketId: secondaryTicket.id },
      body: JSON.stringify({
        status: 5,
        source: secondaryTicket.source,
      }),
    });
    console.log('Successfully merged and closed the ticket');
    return 'Successfully merged and closed the ticket';
  } catch (err) {
    console.error('Failed to auto merge ticket ', err);
    return Error('Failed to auto merge ticket');
  }
}

function sleep(ms) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    let currentTime = null;
    do {
      currentTime = Date.now();
    } while (currentTime - startTime < ms);
    resolve();
  });
}

exports = {
  onAppInstallHandler: function (args) {
    console.info(`onAppInstallHandler invoked with following data: \n${JSON.stringify(args)}`);
    renderData();
  },
  onAppUninstallHandler: function (args) {
    logInfo(`onAppUninstalHandler invoked with following data: \n${JSON.stringify(args)}`);
    renderData();
  },
  onTicketCreateHandler: async function (payload) {
    const iparams = payload.iparams;
    const secondaryTicket = payload.data.ticket;
    const validRequester = validatedRequesterIds(iparams.requesterIds, secondaryTicket.requester_id);
    console.log(
      `Req id: ${secondaryTicket.requester_id}, ticket id: ${secondaryTicket.id}, valid req: ${iparams.validRequester}, requesterIds: ${iparams.requesterIds}, ticketFields: ${iparams.ticketFields}, windowDuration: ${iparams.windowDuration}`
    );
    if (validRequester && secondaryTicket.requester_id) {
      console.log('now: ', Date.now());
      await sleep(10000);
      console.log('after 10 sec delay: ', Date.now());
      try {
        const secondaryTicketResp = await $request.invokeTemplate('getTicketDetailsAPI', {
          context: { ticketId: secondaryTicket.id },
        });
        const updatedSecondaryTicket = JSON.parse(secondaryTicketResp.response).ticket;
        console.log('received latest payload for ticket id: ', updatedSecondaryTicket.id);
        const requesterTicketsResp = await $request.invokeTemplate('getAllTicketsByReqIdAPI', {
          context: { requesterId: updatedSecondaryTicket.requester_id },
        });
        const requesterTickets = JSON.parse(requesterTicketsResp.response).tickets;
        console.log('requesterTickets: ', requesterTickets.length);
        let exitLoop = false;
        requesterTickets.every(async (ticket) => {
          if (ticket.id !== updatedSecondaryTicket.id && ticket.status !== 5 && !exitLoop) {
            if (withInWindow(ticket, updatedSecondaryTicket, iparams.windowDuration)) {
              if (compareTicketFields(ticket, updatedSecondaryTicket, iparams.ticketFields)) {
                exitLoop = true;
                await mergeWithPrimary({
                  primaryTicket: ticket,
                  secondaryTicket: updatedSecondaryTicket,
                });
              }
            }
          } else {
            console.log('Loop skipped:', exitLoop, ticket.id, secondaryTicket.id, ticket.status);
          }
        });
      } catch (err) {
        console.error('Failed to auto merge ticket ', err);
        return Error('Failed to auto merge ticket');
      }
    } else {
      console.log(
        `Requester id is not part of allowed requesters. Requester id: ${secondaryTicket.requester_id}, validRequester: ${validRequester} `
      );
    }
  },
};
